import json


def save_mixing_enthalpy(data_entries, filename):
    """
    将混合焓数据保存到JSON文件。

    :param data_entries: 列表，每个元素为 (元素1, 元素2, 混合焓值)
    :param filename: 保存的文件名
    """
    enthalpy_dict = {}
    for elem1, elem2, enthalpy in data_entries:
        key = tuple(sorted((elem1, elem2)))
        print("key:", key)

        if key in enthalpy_dict:
            print(f"警告: 元素对 {key} 已存在，旧值 {enthalpy_dict[key]} 将被新值 {enthalpy} 覆盖。")
        enthalpy_dict[key] = enthalpy

    json_dict = {f"{a},{b}": enthalpy for (a, b), enthalpy in enthalpy_dict.items()}

    with open(filename, 'w') as f:
        json.dump(json_dict, f, indent=4)
    print(f"数据已保存至 {filename}")


def load_mixing_enthalpy(filename):
    """
    从JSON文件加载混合焓数据。

    :param filename: 文件名
    :return: 字典，键为排序后的元素元组，值为混合焓
    """
    with open(filename, 'r') as f:
        json_dict = json.load(f)

    enthalpy_dict = {}
    for key_str, enthalpy in json_dict.items():
        a, b = key_str.split(',')
        enthalpy_dict[(a, b)] = float(enthalpy)

    return enthalpy_dict


def get_mixing_enthalpy(enthalpy_dict, elem1, elem2):
    """
    获取两个元素的混合焓。

    :param enthalpy_dict: 混合焓字典
    :param elem1: 元素1符号
    :param elem2: 元素2符号
    :return: 混合焓值（不存在时返回None）
    """
    key = tuple(sorted((elem1, elem2)))
    return enthalpy_dict.get(key, None)


# 示例使用
if __name__ == "__main__":
    # 示例数据（可替换为实际数据）
    test_data = [
        ('Fe', 'Cu', 5.2),
        ('Al', 'Cu', 3.4),
        ('Cu', 'Fe', 4.8),  # 覆盖Fe-Cu数据
        ('Mg', 'Al', -1.2)
    ]

    # 保存数据到文件
    save_mixing_enthalpy(test_data, 'mixing_enthalpies.json')

    # 从文件加载数据
    enthalpy_db = load_mixing_enthalpy('mixing_enthalpies.json')

    # 查询示例
    print(get_mixing_enthalpy(enthalpy_db, 'Fe', 'Cu'))  # 输出4.8
    print(get_mixing_enthalpy(enthalpy_db, 'Cu', 'Fe'))  # 输出4.8
    print(get_mixing_enthalpy(enthalpy_db, 'Al', 'Mg'))  # 输出-1.2
    print(get_mixing_enthalpy(enthalpy_db, 'Au', 'Ag'))  # 输出None