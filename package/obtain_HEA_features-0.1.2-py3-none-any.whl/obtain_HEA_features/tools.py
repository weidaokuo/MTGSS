from obtain_HEA_features.dataset.lookup_data import EP
from obtain_HEA_features.utils import load_mixing_enthalpy, get_mixing_enthalpy
import math
import os
import pkg_resources


# 可以预留一个质量分数转化为摩尔分数的公式
class WDK_select(object):
    """
    :param element_list, Eg: ["Al", "Co", "Cr", "Fe"]
    :param composition_list, Eg:[0.20, 0.40, 0.30, 0.10], num=1
    """

    def __init__(self, element_list, composition_list, mole_fraction=True):
        self.element_list = element_list
        if mole_fraction == True:

            self.composition_list = WDK_select.fraction_list_charge(composition_list)
        else:

            self.composition_list = WDK_select.translate(element_list, WDK_select.weight_list_charge(composition_list))

        path = pkg_resources.resource_filename("obtain_HEA_features", "dataset/all_mixing_enthalpies.json")
        # path = os.path.join(os.path.dirname(__file__), "dataset", "all_mixing_enthalpies.json")
        #print(path)
        self.enthalpy_db = load_mixing_enthalpy(path)

    @staticmethod
    def fraction_list_charge(lst):
        """
        判断列表中的最大值：
        - 如果最大值 <= 1，不做任何变化。
        - 如果存在大于 1 的值，将所有数值除以 100。
        """
        if max(lst) > 1:
            return [x / 100 for x in lst]
        return lst

    @staticmethod
    def weight_list_charge(lst):
        """
        判断列表中的最大值：
        - 如果最大值 小于等于 1，将所有数值乘以100。
        - 如果存在大于 1 的值，不做任何变化。
        """
        if max(lst) <= 1:
            return [x*100 for x in lst]
        return lst
    @staticmethod
    def translate(element_list, composition_list):
        output_list = []
        for i, j in zip(element_list, composition_list):
            M = EP.molar_masses[i]
            output_list.append(j / M)
        n_total = sum(output_list)
        composition_fraction = list(map(lambda x: x / n_total, output_list))
        return composition_fraction

    # 平均价电子浓度
    def vec(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.vec[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有vec性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 内聚能
    def cohesive_energy(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.cohesive_energy[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有cohesive_energy性质！")
            output_list.append(j * value)
        return sum(output_list)

    #体积模量
    def bulk_modulus(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.bulk_modulus[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有bulk_modulus性质！")
            output_list.append(j * value)
        return sum(output_list)
    # 平均电负性
    def average_electronegativity(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.electronegativity[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有average_electronegativity性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 平均电负性差异
    def electronegativity_difference(self):
        output_list = []
        ave_elect = self.average_electronegativity()
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.electronegativity[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有electronegativity_difference性质！")
            output_list.append(j * ((value - ave_elect) ** 2))
        # print(output_list)
        return math.sqrt(sum(output_list))

    # 平均原子尺寸
    def average_atomic_size(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.atomic_r[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有atomic_size性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 原子尺寸差异
    def atomic_size_difference(self):
        output_list = []
        ave_atom_size = self.average_atomic_size()
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.atomic_r[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有atomic_size_difference性质！")
            output_list.append(j * (1 - value / ave_atom_size) ** 2)
        return 100 * math.sqrt(sum(output_list))

    # 混合熵：单位J/(mol·K)，其中R=8.314
    def mixed_entropy(self):
        R = 8.314
        output_list = []
        for ci in self.composition_list:
            output_list.append(ci * math.log(ci))
        return -R * sum(output_list)

    # 混合焓计算,单位KJ/mol
    def mixed_enthalpy(self):
        """
        计算混合焓。
        :param elements: 元素名称列表，例如 ["Ni", "Co", "Fe"]
        :param compositions: 元素成分列表，例如 [0.3, 0.5, 0.2]
        :return: 混合焓值
        """
        # 从文件加载数据
        n = len(self.element_list)
        mixing_enthalpy = 0.0

        # 遍历所有元素对
        # print("元素个数：", n)
        for i in range(n):
            for j in range(n):
                if j > i:
                    # 获取元素 i 和 j 之间的焓
                    enthalpy = get_mixing_enthalpy(self.enthalpy_db, self.element_list[i], self.element_list[j])
                    # print(enthalpy)
                    # 计算贡献值并累加
                    # print(self.composition_list[i] * self.composition_list[j] * enthalpy*4)
                    mixing_enthalpy += self.composition_list[i] * self.composition_list[j] * enthalpy * 4
        return mixing_enthalpy

    # 各元素熔点的加权平均值
    def Tm(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.atomic_Tm[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有Tm性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素密度的加权平均值
    def density(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.atomic_density[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有density性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素弹性模量的加权平均值
    def elastic_modulus(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.Elastic_modulus[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有elastic_modulus性质！")
            output_list.append(j * value)
        return sum(output_list)

    #熔化焓
    def melting_enthalpy(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.melting_enthalpy[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有melting_enthalpy性质！")
            output_list.append(j * value)
        return sum(output_list)


    # 各元素热膨胀系数的加权平均值
    def thermal_expansion(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.thermal_expansion_coefficient[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有thermal_expansion性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素热导率的加权平均值
    def thermal_conductivity(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.thermal_conductivity[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有thermal_conductivity性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素比热容的加权平均值
    def specific_heat(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.specific_heat[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有specific_heat性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素晶格常数的加权平均值
    def lattice_constant(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.lattice_constant[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有lattice_constant性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素硬度的加权平均值
    def hardness(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.hardness[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有hardness性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素电子密度的加权平均值
    def electron_density(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.electron_density[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有electron_density性质！")
            output_list.append(j * value)
        return sum(output_list)

    # 各元素电子密度的加权平均值
    def G(self):
        output_list = []
        for i, j in zip(self.element_list, self.composition_list):
            value = EP.G[i]
            if isinstance(value, str):
                raise ValueError("存在元素没有G性质！")
            output_list.append(j * value)
        return sum(output_list)

    def omega(self):
        Tm = self.Tm()
        mix_entropy = self.mixed_entropy()
        mix_enthalpy = self.mixed_enthalpy()
        omega = (Tm * mix_entropy) / abs(mix_enthalpy * 1000)
        return omega


if __name__ == "__main__":
    element_list = ["Fe", "Co", "Ni", "C"]
    composition_list = [0.3, 0.2, 0.4, 0.1]
    wdk = WDK_select(element_list, composition_list)
    mix_entropy = wdk.mixed_entropy()
    avg_atom_size = wdk.average_atomic_size()
    dif_electronegativity = wdk.electronegativity_difference()
    name_list = ["mixed_enthalpy", "mixed_entropy", "electronegativity_difference",
                 "average_electronegativity", "omega"]
    for i in name_list:
        method = getattr(wdk, i)()  # 通过名字调用实例中的方法
        print(method)
    # print(mix_entropy, avg_atom_size, dif_electronegativity)
