from obtain_HEA_features.tools import WDK_select



class Wdk_made_feature(WDK_select):
    """
    :param element_list is a list like ["Fe", "Co", "Ni"]
    :param composition_list is a list like [0.1, 0.5, 0.4]
    :param name_list is a list like ["vae", electronegativity], it must be a subset of default value.
    """

    def __init__(self, element_list, composition_list, name_list=None, mole_fraction=True):
        super().__init__(element_list, composition_list, mole_fraction)
        if name_list is not None:
            self.name_list = name_list
        else:
            self.name_list = [
                              "vec", "cohesive_energy", "bulk_modulus", "average_electronegativity",
                              "electronegativity_difference","average_atomic_size", "atomic_size_difference",
                              "mixed_entropy","mixed_enthalpy", "Tm", "density", "elastic_modulus", "melting_enthalpy",
                              "thermal_expansion","thermal_conductivity", "specific_heat", "lattice_constant",
                              "hardness", "electron_density", "G", "omega"
                              ]


    def get_features(self):
        feature_list = []
        for feature_name in self.name_list:
            if hasattr(self, feature_name):
                feature_value = getattr(self, feature_name)()
                feature_list.append(feature_value)
        return feature_list

if __name__ == "__main__":
    element_list = ["Nb", "W", "Mo", "Zr", "C"]
    composition_list = [94.71, 2.64, 1.69, 0.73, 0.24]
    # composition_list = [0.9471, 0.0264, 0.0169, 0.0073, 0.0024]
    #composition_list = [0.9444515465002269, 0.013304284498132007, 0.01631809034460354, 0.00741380837345979, 0.018512270283577843]
    name_list = ["atomic_size_difference", "average_atomic_size", "electronegativity_difference",
                              "mixed_entropy", "mixed_enthalpy", "average_electronegativity","electronegativity_difference"]
    output = Wdk_made_feature(element_list, composition_list, name_list, mole_fraction=True).get_features()
    print(output, len(output))
